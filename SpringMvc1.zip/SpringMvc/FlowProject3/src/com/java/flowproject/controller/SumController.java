package com.java.flowproject.controller;

import com.java.flowproject.dto.SumDto;
import com.java.flowproject.service.SumService;

public class SumController {
private SumService sumService;

public void setSumService(SumService sumService) {
	this.sumService = sumService;
}

public void doMathCal(SumDto sumDto)
{
	System.out.println("controller is start");

	sumService.calculate(sumDto);
	System.out.println("controller is end");

}
}
