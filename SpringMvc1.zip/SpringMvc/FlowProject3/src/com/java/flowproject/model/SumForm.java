package com.java.flowproject.model;

public class SumForm {
private int fno;
private int sno;
private int sum;
public int getFno() {
	return fno;
}
public void setFno(int fno) {
	this.fno = fno;
}
public int getSno() {
	return sno;
}
public void setSno(int sno) {
	this.sno = sno;
}
public int getSum() {
	return sum;
}
public void setSum(int sum) {
	this.sum = sum;
}

}
