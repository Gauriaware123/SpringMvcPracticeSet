package com.java.flowproject.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.java.flowproject.dao.SumDao;
import com.java.flowproject.model.SumForm;

public class SumDaoImpl implements SumDao {
private JdbcTemplate jdbcTemplate;

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}

@Override
public void insertNumbers(SumForm sumForm) {
	System.out.println("dao is start");

 String query="insert into sumtable values(" + sumForm.getFno() + " , " + sumForm.getSno() + " ,"+ sumForm.getSum() + ")";	
 jdbcTemplate.update(query);
	System.out.println("dao is end");

}
}
