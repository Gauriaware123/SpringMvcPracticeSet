package com.java.flowproject.dao;

import com.java.flowproject.model.SumForm;

public interface SumDao {
 void insertNumbers(SumForm sumForm);
}
