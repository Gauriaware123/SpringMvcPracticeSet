package com.java.flowproject;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.java.flowproject.controller.SumController;
import com.java.flowproject.dto.SumDto;

public class Demo {

	public static void main(String[] args) {
    System.out.println("application is start");

    Resource resource = new ClassPathResource("applicationContext.xml");
    BeanFactory beanFactory = new XmlBeanFactory(resource);
    SumDto sumDto = new SumDto();
    sumDto.setFno(100);
    sumDto.setSno(200);
    SumController sc =(SumController)beanFactory.getBean("idSumController");
    sc.doMathCal(sumDto);
	System.out.println("application  is end");

	}

}
