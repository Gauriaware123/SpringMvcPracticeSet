package com.java.flowproject.service;

import com.java.flowproject.dto.SumDto;

public interface SumService {
void claculate(SumDto sumDto);
	
}
