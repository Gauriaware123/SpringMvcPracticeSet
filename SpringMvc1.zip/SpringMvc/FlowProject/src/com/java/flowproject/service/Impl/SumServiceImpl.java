package com.java.flowproject.service.Impl;

import com.java.flowproject.dao.SumDao;
import com.java.flowproject.dto.SumDto;
import com.java.flowproject.model.SumForm;
import com.java.flowproject.service.SumService;

public class SumServiceImpl implements SumService{

	private SumDao sumDao;
	
	
	public SumDao getSumDao() {
		return sumDao;
	}
	public void setSumDao(SumDao sumDao) {
		this.sumDao = sumDao;
	}
	
	@Override
	public void claculate(SumDto sumDto) {
		System.out.println("service method start here");
		int fno=sumDto.getFno();
		int sno=sumDto.getSno();
		int sum = fno+sno;
		int sub=fno-sno;
		
		sumDto.setSum(sum);
		sumDto.setSub(sub);
		
		SumForm sumform = new SumForm();
		sumform.setFno(sumDto.getFno());
		sumform.setSno(sumDto.getSno());
		sumform.setSum(sumDto.getSum());
		sumDao. insertNumbers(sumform);
		
		System.out.println("service ends hear");
	}
 
}
