package com.java.flowproject.Controller;

import com.java.flowproject.dto.SumDto;
import com.java.flowproject.service.SumService;

public class SumController {

	private SumService sumService;

	public void setSumService(SumService sumService) {
		this.sumService = sumService;
	}
	
	public void doMathCal(SumDto sumDto)
	{
		
		System.out.println("controller start hear");
		sumService.claculate(sumDto);
		System.out.println("controller end hear");
	}
}
