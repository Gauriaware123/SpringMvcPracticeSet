package com.java.flowproject.dao.Impl;

import java.sql.*;

import com.java.flowproject.dao.SumDao;
import com.java.flowproject.model.SumForm;

public class SumDaoImpl implements SumDao {

	@Override
	public void insertNumbers(SumForm sumform) {
      System.out.println("Dao starts hear");
      Connection con = null;
      try {
    	  Class.forName("oracle.jdbc.driver.OracleDriver");
    	  con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "system","1234");
    	  String query="insert into sumtable values("+sumform.getFno()+","+ sumform.getSno()+","+sumform.getSum()+")";
          Statement stmt = con.createStatement();
    	  stmt.executeUpdate(query);
    	  stmt.close();
    	  con.close();
      } 
      catch(Exception e)
      {
    	  System.out.println(e);
      }
      
	}

}
