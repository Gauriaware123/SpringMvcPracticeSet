package com.java.flowproject;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.java.flowproject.Controller.SumController;
import com.java.flowproject.dto.SumDto;

public class Demo {

	public static void main(String[] args) {
		
	  System.out.println("Application Start here");  
      Resource resource = new ClassPathResource("ApplicationContext.xml");
      BeanFactory beanfactory = new XmlBeanFactory(resource);

	  SumDto sumDto=new SumDto();
	  sumDto.setFno(100);
	  sumDto.setSno(20);
	  
	  SumController sc=(SumController)beanfactory.getBean("idSumController");
	  sc.doMathCal(sumDto);
	  
	  System.out.println("Sum=" + sumDto.getSum());
      System.out.println("Sub=" + sumDto.getSub());
	  System.out.println("Application ends here");
   }
}


