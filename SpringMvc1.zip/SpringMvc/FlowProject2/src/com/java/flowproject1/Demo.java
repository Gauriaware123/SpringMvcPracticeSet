package com.java.flowproject1;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.java.flowproject1.controller.SumController;
import com.java.flowproject1.dto.SumDto;

public class Demo {
public static void main(String[] args) {
	Resource  resource = new ClassPathResource("applicationContext.Xml");
	BeanFactory beanFactory = new XmlBeanFactory(resource);
	SumDto sumDto = new SumDto();
	sumDto.setFno(300);
	sumDto.setSno(157);
	
	SumController sc = (SumController)beanFactory.getBean("idSumController");
	sc.doMathCal(sumDto);
 } 
}
