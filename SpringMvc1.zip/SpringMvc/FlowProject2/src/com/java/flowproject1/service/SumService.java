package com.java.flowproject1.service;

import com.java.flowproject1.dto.SumDto;

public interface SumService {
void claculate(SumDto sumDto);

}
