package com.java.flowproject1.service.impl;

import com.java.flowproject1.dao.SumDao;
import com.java.flowproject1.dto.SumDto;
import com.java.flowproject1.model.SumForm;
import com.java.flowproject1.service.SumService;

public class SumServiceImpl implements SumService {
 private SumDao sumDao;

public void setSumDao(SumDao sumDao) {
	this.sumDao = sumDao;
}



@Override
public void claculate(SumDto sumDto) {
	System.out.println("Service start here");
	int fno = sumDto.getFno();
	int sno = sumDto.getSno();
	int sum = fno + sno;
	int sub = fno-sno;
	sumDto.setSum(sum);
	sumDto.setSub(sub);
	//System.out.println(sum);
	//System.out.println(sub);

	SumForm sumform = new SumForm();
	
	sumform.setFno(sumDto.getFno());
	sumform.setSno(sumDto.getSno());
	sumform.setSum(sumDto.getSum());
	
	sumDao.insertNumbers(sumform);
	System.out.println("Service ends here");
}
}
 
