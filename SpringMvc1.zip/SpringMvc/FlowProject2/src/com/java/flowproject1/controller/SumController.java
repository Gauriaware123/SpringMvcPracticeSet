package com.java.flowproject1.controller;

import com.java.flowproject1.dto.SumDto;
import com.java.flowproject1.service.SumService;

public class SumController {
private SumService sumService;

public void setSumService(SumService sumService) {
	this.sumService = sumService;
}

public void doMathCal(SumDto sumDto)
  {
	System.out.println("Controller starts hear");
	sumService.claculate(sumDto);
	System.out.println("Controller starts hear");

   }
 }
