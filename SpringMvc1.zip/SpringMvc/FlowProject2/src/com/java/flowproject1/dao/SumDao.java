package com.java.flowproject1.dao;

import com.java.flowproject1.model.SumForm;

public interface SumDao {

	void insertNumbers(SumForm sumForm );
}
