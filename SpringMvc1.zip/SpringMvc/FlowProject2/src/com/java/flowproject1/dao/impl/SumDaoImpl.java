package com.java.flowproject1.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.java.flowproject1.dao.SumDao;
import com.java.flowproject1.model.SumForm;

public class SumDaoImpl implements SumDao{
private JdbcTemplate jdbcTemplate;

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}

@Override
public void insertNumbers(SumForm sumForm) {
	System.out.println("Dao starts hear");
	String query="Insert into sumtable values(" + sumForm.getFno() + "," + sumForm.getSno() + "," + sumForm.getSum() + ")";
    jdbcTemplate.update(query);	
	System.out.println("Dao ends hear");

}

}
